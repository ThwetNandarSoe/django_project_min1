#! C:\Program Files\Python36\python.exe
import cgi
import cgitb;cgitb.enable()

print("Content-type:text/html\n\n")

print("""
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Register Form</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<style>
body{
    text-align:center;
}
h1{
    margin-top:5%;
    text-align:center;
}
form{
    position: relative;
  margin: 20px auto;
  width: 50%;
  text-align:left;
  padding: 33px 25px 29px;
  background: white;
  border-bottom: 2px solid blue;
  border-left: 2px solid red;
  border-top: 2px solid red;
  border-right:2px solid blue;
  border-radius: 5px;
  -webkit-box-shadow: 0 1px 5px rgba(0, 0, 0, 0.25);
  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.25);
}
.text{
    width: 100%;
  height: 50px;
  margin-bottom: 25px;
  font-size: 17px;
  background: white;
  border: 2px solid #ebebeb;
  border-radius: 4px;
  -webkit-box-shadow: inset 0 -2px #ebebeb;
  box-shadow: inset 0 -2px #ebebeb;
}
</style>
<body>

<div class="form">
<h1>Register Form</h1>
<form method="post" action="register1.py">
Firstname:<br>
<input type="text" name="firstname" placeholder="firstname" class="text" required /><br>
Lastname:<br>
<input type="text" name="lastname" placeholder="lastname" class="text" required /><br>
Dob:<br>
<input type="dob" name="dob" required class="date" /><br>
Email:<br>
<input type="email" name="email" class="email" placeholder="@gmail.com" required /><br>
Gender:<br>
<input type="gender" name="" placeholder="gender" class="text" required /><br>
<input type="submit" name="submit" value="Submit">
</form>
</div>
</body>
</html>

""")
