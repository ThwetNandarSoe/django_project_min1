#! C:\Program Files\Python36\python.exe
import MySQLdb
import cgi
import cgitb;  
cgitb.enable()  #to track cgi error
print("Content-type: text/html\n\n")
db =MySQLdb.connect(host="localhost", port=3306, user="root", password="", db="python")
cursor = db.cursor()
form=cgi.FieldStorage()
def getFieldValue(fieldname):
    if fieldname in form:
        return form[fieldname].value
if "submitted" in form:
    firstname=getFieldValue("firstname")
    lastname=getFieldValue("lastname")
    dob=getFieldValue("dob")
    email=getFieldValue("email")
    gender=getFieldValue("gender")
    
    
    try:
        cursor.execute("insert into pythonreg (firstname,lastname,dob,email,gender) values('{0}','{1}','{2}','{3}','{4}')".format(firstname, lastname,dob,email,gender))
        print(firstname,  lastname, dob, email, gender,'successfully inserted')
        db.commit()
    except:
        print("Error occured")
        db.rollback()
db.close    
